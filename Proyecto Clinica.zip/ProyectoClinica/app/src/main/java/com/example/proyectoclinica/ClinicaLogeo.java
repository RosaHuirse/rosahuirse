package com.example.proyectoclinica;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ClinicaLogeo extends AppCompatActivity {

    Button siguiente;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Rosa
        setContentView(R.layout.activity_clinica_logeo);
        siguiente=(Button)findViewById(R.id.button);

        siguiente.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent i = new Intent(ClinicaLogeo.this, ClinicaListarCita.class);
                startActivity(i);
            }
        });
        //Fin
    }
}